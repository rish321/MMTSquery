#!/bin/bash

cat folderfindTheme | sed -e "s/actions/$1/g"
