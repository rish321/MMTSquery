#!/bin/bash

cat folderfindOutAction | sed -e "s/condition/$1/g"
