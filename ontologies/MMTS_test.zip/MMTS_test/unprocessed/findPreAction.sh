#!/bin/bash

cat folderfindPreAction | sed -e "s/condition/$1/g"
