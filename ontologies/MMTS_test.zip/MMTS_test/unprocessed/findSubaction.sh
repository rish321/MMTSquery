#!/bin/bash

cat folderfindSubaction | sed -e "s/actions/$1/g"
