#!/bin/bash

cat folderfindPrecondition | sed -e "s/action/$1/g"
